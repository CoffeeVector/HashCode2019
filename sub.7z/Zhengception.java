
public class Zhengception extends Exception {

	public Zhengception(String string) {
		super(string);
	}

}
